package playlist;

import java.util.ArrayList;

public class playlist {
    private ArrayList<String> songs;
    private int capacity;

    public playlist(int capacity) {
        this.songs = new ArrayList<String>();
        this.capacity = capacity;
    }

    public void addSong(String song) {
        if (songs.size() >= capacity) {
            songs.remove(0);
        }
        songs.add(song);
    }

    public void playSong(String song) {
        if (songs.contains(song)) {
            songs.remove(song);
        }
        addSong(song);
    }

    public void printPlaylist() {
        System.out.println(songs.toString());
    }

    public static void main(String[] args) {
        playlist playlist = new playlist(3);
        playlist.addSong("S1");
        playlist.addSong("S2");
        playlist.addSong("S3");
        playlist.printPlaylist(); 

        playlist.playSong("$4");
        playlist.printPlaylist();
        
        playlist.playSong("$2");
        playlist.printPlaylist(); 

        playlist.playSong("S1");
        playlist.printPlaylist(); 
    }

	}

